# rijksoverheidfonts

* TrueType (TTF) fonts plucked from [studiodumbar/ezines](https://github.com/studiodumbar/ezines/tree/master/assets/type)

* In use by the [Dutch Government](https://www.government.nl/contact) (Rijksoverheid)

_**Only use this fonts if you have permission**_

###### No copyright infringment is intended - please contact me if removal is necessary


